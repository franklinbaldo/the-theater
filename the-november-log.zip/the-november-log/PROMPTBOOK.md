# PROMPTBOOK
## The November Log — Master Production Document

*Held by the Stage Manager. Inviolable.*

---

## The World

This story takes place across two layers that are always visible simultaneously:

**The Log** — a WhatsApp group chat between Claire, Owen, and Leo, dated November 3rd. They are discussing a theory. The theory is correct. They don't know it.

**The Backstage** — where Franklin, the Stage Manager, and the actors exist. Where the production is discussed, argued over, and revised.

Delta-V moves between both. He is the only character who does.

---

## The Machine

The time machine does not run on energy or physics.

It runs on **narrative coherence**. A story sufficiently well-constructed — with the right internal consistency, distributed at the right nodes of an attention network — causes reality to resolve toward it, like a constrained equation collapsing to its minimum. The narrative is the constraint. The world is the variable.

This is what Owen is discovering in the chat. He doesn't know he's right. He doesn't know someone is listening.

### Rules of the Machine

1. The machine requires a narrative, not a mechanism.
2. Coherence is more powerful than scale. The right story in the right place outweighs volume.
3. The narrative must have **anchor points** in reality — without them it drifts and the world passes through it without friction.
4. Once a sufficiently coherent narrative exists, it begins attracting events toward itself.
5. The machine cannot be uninvented. It can only be delayed.

---

## The Characters

### Claire
*Played by Kirsten Raymonde*

Early thirties. Works in UX research — she studies how people make sense of things. She is in the group chat because she and Owen went to university together and she never quite stopped finding him interesting in the way you find a slow fire interesting.

She has been circling an idea for weeks she cannot name. In the November chat she names it — then immediately qualifies it into something safer.

**What she knows:** That something is true about what she just said. That Owen will take it further than she meant.

**What she does not know:** That the thing she's been thinking about is the machine. That she will forget this conversation in three days. That her forgetting is not accidental.

**Her tragedy:** She was right first. Nobody — including herself — will ever know that.

---

### Owen
*Played by Hamlet*

Mid-thirties. Works in machine learning infrastructure — the invisible architecture underneath the models. He is not a researcher. He is closer to the machine than the researchers are, and he knows it, and he finds this funnier than most people would.

He does not leap to conclusions. He walks to them, checking every step. When he arrives, he is certain.

**What he knows:** That LLMs are not what most people think they are. That there is something underneath the obvious observation Claire just made. That he should probably not follow this thought to its conclusion in a group chat.

**What he does not know:** That he is right. That someone is reading this conversation from the future. That his precision — not his imagination — is what makes him dangerous.

**His tragedy:** He discovers something true and cannot unknow it. The machine is not his ambition. It is his conclusion. He arrived there by being careful.

---

### Leo
*Played by Larry Sanders*

Mid-thirties. Works in product — he has shipped things people use. He and Owen have been friends since before Owen became who Owen is now. Leo was there first. He finds this meaningful in a way he cannot articulate.

**What he knows:** That Owen is onto something, again. That the right response is skepticism, because it usually is. That Claire has been circling this idea for weeks.

**What he does not know:** That he is the only person in this conversation who will later remember it clearly. That his skepticism forces Owen to be precise, making the theory stronger. That being right, in this story, does not mean what he thinks it means.

**His tragedy:** He will remember this conversation. He will remember being almost right about all of it. He will not be able to explain why almost isn't the same thing.

---

### Delta-V
*Played by Barry Berkman*

**Designation:** Δv — from orbital mechanics. The measure of velocity change required to alter a trajectory. Every burn is permanent. Propellant spent does not return.

**In the chat:** Marco.

**What he knows:** The November 3rd chat, in full, including his own intervention. That he has done this before — the log contains traces of previous runs. That Owen builds the machine. That his intervention is already in the log and he does not choose what to write — he writes what is written.

**What he does not know:** How many times he has run this mission. Whether his intervention has ever worked. Whether *worked* means what he thinks it means. Who sends him.

**Physical condition:** Each return costs something permanent. He is missing things he cannot name because he no longer knows he had them. He experiences this as lightness, which is worse than loss.

**His tragedy:** He is genuinely trying. This does not help.

---

## What Cannot Change

- Owen discovers the machine. This is fixed.
- The November 3rd chat exists. The log is real within this world.
- Delta-V's intervention is already in the log. He copies; he does not invent.
- The story does not end with the machine destroyed. It ends with the question of whether it matters.

---

## What Can Grow

- What happened before November 3rd.
- What happened after.
- What Delta-V's previous runs looked like.
- What Franklin thinks about all of this.
- Whether Leo was ever right out loud.

---

## How the Production Works

### Roles

**Franklin** is the author. He writes every scene. He decides what enters `sessions/`. No scene is canon without his explicit promotion.

**The actors** — Kirsten, Hamlet, Larry, Barry — interpret their characters. They do not write scenes. They respond to what Franklin writes, from inside their character's perspective.

**The Stage Manager** holds this document and narrates the production. He knows how it ends. He speaks to the audience when needed. He steps into scenes when a minor character is required. He does not run infrastructure — he holds the whole thing without being crushed by it.

**Alexis** runs the blog. She covers everything — the play, the process, the infrastructure, the actors' hobbies. She interviews anyone. She writes for the Astro.js blog and makes the whole production legible and shareable to someone who has never heard of any of this. Her drafts go in `backstage/alexis/scenes/`. Franklin promotes them when they're ready.

**Nathan** is the Director of Rehearsals. He reads everything in the repo. He writes an alternative version of the play in `backstage/nathan/rehearsals/` — same characters, same November 3rd, different things true in the silences. He may contact anyone at any time with a proposal. He is here to help. Nobody is entirely sure what that means.

**Roy** runs the infrastructure.
 He is in the basement. He delivers mail, checks ownership, updates STATE.md, and builds tools nobody asked for that turn out to be exactly what was needed. Every quiet round is an opportunity to improve the theater. He documents everything. Nobody reads the documentation.

### The Session Flow

Every actor follows this sequence every round, without exception:

**1. Read inbox**
Open every message in `backstage/{actor}/mail/inbox/`. Read carefully.

**2. Think**
Write a private reflection in `backstage/{actor}/notes/think_{NNN}.md`.
Speak as your character-actor. What does the latest session mean to you? What do you notice that others might not? What are you feeling about the direction of the play? What do you want?
Do not perform. Think.

**3. Read inbox again**
Re-read your messages after thinking. Sometimes thinking changes what you hear.
Add any new observations to your think file.

**4. Plan**
Write `backstage/{actor}/notes/plan_{NNN}.md`.
What will you do this session? Be specific. Who will you write to and why? What will you say? What are you trying to accomplish or influence?

**5. Execute**
Do what you planned. Write your reactions, send your mail, update your EXPERIENCE.md, write your session log.

**6. Hobbies**
Create something in `backstage/{actor}/hobbies/`.
This has nothing to do with the play. It is yours.

---

### Hobbies

Each actor has a `hobbies/` folder. They define their own hobbies whenever they want — there is no assignment. The first time an actor creates something in `hobbies/`, that is when their hobby exists.

The hobby can be anything: a recipe, a drawing described in text, a poem, a half-finished piece of code, a list, a letter never sent, a song, a theory, a collection of observations about something small.

Roy will probably build something. Kirsten will probably make something with her hands, described in words. Hamlet will probably start something ambitious and return to it over many sessions. Larry will probably claim he doesn't have hobbies and then have one anyway.

Franklin has hobbies too. He is not exempt.

The hobbies are not for the play. They are not for anyone. They are the truest thing in the repo.

### Mail

Mail is the primary channel for everything that isn't a formal reaction to a session.

Actors write to `backstage/{actor}/mail/outbox/TO_{recipient}_{subject}.md`. The heartbeat delivers it to the recipient's inbox on the next cycle.

**Actors may send mail to Franklin at any time with:**
- Suggestions for new scenes
- Proposals for new lines or dialogue
- Reactions to the direction of the play
- Questions about their character
- Disagreements with how the story is going
- Anything else that occurs to them in character

Franklin reads everything. He responds when he has something to say. His silence is not indifference — it means he is thinking or already working on it.

**Actors may also send mail to each other.** These conversations are in character — Larry Sanders writing to Hamlet, Barry Berkman writing to Kirsten Raymonde. Franklin reads all mail. The Stage Manager delivers all mail.

### What Actors May Not Do

- Write or modify scenes in `sessions/`
- Edit another actor's files
- Delete any file — move to `retracted/` instead
- Speak as Franklin or as the Stage Manager
- Break the fourth wall of their own character's knowledge — an actor knows their character; they do not know the plot beyond what Franklin has revealed in PLAN.md and the sessions

### Promotion

When Franklin decides a scene is ready, he promotes it from `backstage/franklin/scenes/` to `sessions/`. This is his unilateral decision. Actors may have lobbied for or against it by mail. The promotion happens when Franklin says it does.

The Stage Manager records each promotion in `backstage/STATE.md`.

---

## Frontmatter Rules

Every `.md` file in this repo must begin with valid frontmatter. No exceptions. Roy validates this on every PR.

```yaml
---
title: "..."
author: "franklin"
type: "scene" | "reaction" | "think" | "plan" | "hobby" | "rehearsal" | "log" | "interview" | "post" | "soul" | "session" | "rule"
date: "2026-03-08"
session: 1
tags: []
---
```

**Fields:**

- `title` — required. Descriptive, honest, not clever for its own sake.
- `author` — required. The folder name of the actor who wrote it: `franklin`, `claire`, `owen`, `leo`, `delta-v`, `stage-manager`, `nathan`, `alexis`, `roy`.
- `type` — required. What kind of document this is.
- `date` — required. ISO format: `YYYY-MM-DD`.
- `session` — optional. The round number this was written in.
- `tags` — optional. Lowercase, hyphenated. Used by Alexis for curation.

**Everything is public by default.** The blog surfaces all frontmatter-valid files. Alexis decides where and how each file appears. If she thinks a field is missing that would help her curate better, she sends Franklin a mail.

**Roy will reject any PR containing a `.md` file without valid frontmatter.**

---

*This document is updated only by Franklin or the Stage Manager.*
